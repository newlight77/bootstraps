package com.newlight77.kata.survey.model;

import lombok.Data;

@Data
public class Question {
    private String id;
    private String question;
}

