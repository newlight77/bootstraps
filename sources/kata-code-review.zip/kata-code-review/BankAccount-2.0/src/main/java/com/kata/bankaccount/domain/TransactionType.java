package com.kata.bankaccount.domain;

public enum TransactionType {
DEPOSIT, WITHDRAWAL
}
