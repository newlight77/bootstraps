package com.kata.tdd;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class StringComputeTest {

	private StringCompute stringComputeUnderTest;

	@Before
	public void setUp() throws Exception {
		stringComputeUnderTest = new StringCompute();
	}

	@Test
	public void failTestComputeWith8() {
		// fail("Not yet implemented");
		String s = "8";
		String output = "Foo";
		assertEquals(output, stringComputeUnderTest.compute(s));
	}

	@Test
	public void successTestComputeWith3() {
		// fail("Not yet implemented");
		String s = "3";
		String output = "FooFoo";
		assertEquals(output, stringComputeUnderTest.compute(s));
	}
	
	@Test
	public void successTestComputeWith33() {
		// fail("Not yet implemented");
		String s = "33";
		String output = "FooFooFoo";
		assertEquals(output, stringComputeUnderTest.compute(s));
	}
	
	@Test
	public void successTestComputeWith51() {
		// fail("Not yet implemented");
		String s = "51";
		String output = "FooBar";
		assertEquals(output, stringComputeUnderTest.compute(s));
	}
	
	@Test
	public void successTestComputeIncludingZero() {
		// fail("Not yet implemented");
		String s = "303";
		String output = "FooFoo*Foo";
		assertEquals(output, stringComputeUnderTest.compute(s));
	}

	@Test
	public void failTestCheckContainsRule() {
		// fail("Not yet implemented");
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkContainsRule("4"));
	}

	@Test
	public void SuccessTestCheckContainsRule() {
		// fail("Not yet implemented");
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkContainsRule("3"));
		//assertEquals(b, stringComputeUnderTest.checkContainsRule("5"));

	}

	@Test
	public void failTestCheckDivisionRule() {
		// fail("Not yet implemented");
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkDivisionRule("4"));
	}

	@Test
	public void SuccessTestCheckDivisionRule() {
		// fail("Not yet implemented");
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkDivisionRule("3"));
		assertEquals(b, stringComputeUnderTest.checkDivisionRule("5"));

	}
	
	@Test
	public void FailTestCheckContainsZero() {
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkContainsZero("11"));
	}
	
	@Test
	public void SuccessTestCheckContainsZero() {
		boolean b = true;
		assertEquals(b, stringComputeUnderTest.checkContainsZero("102"));
	}
	

}
