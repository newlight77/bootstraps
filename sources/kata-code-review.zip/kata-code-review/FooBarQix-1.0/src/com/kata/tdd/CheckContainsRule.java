package com.kata.tdd;

public interface CheckContainsRule {
	
	boolean checkContainsRule (String s);

}
