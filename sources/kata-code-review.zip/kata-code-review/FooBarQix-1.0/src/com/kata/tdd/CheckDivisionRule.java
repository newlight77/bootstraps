package com.kata.tdd;

public interface CheckDivisionRule {
	
	boolean checkDivisionRule (String s);

}
