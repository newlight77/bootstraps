package com.kata.tdd;

public class StringCompute implements CheckContainsRule, Converter, CheckDivisionRule, CheckContainsZero {

	public static int x = 3;
	public static int y = 5;
	public static int z = 7;
	public static int zero = 0;

	@Override
	public String compute(String s) {
		// TODO Auto-generated method stub

		if ((this.checkContainsRule(s) == true) && (this.checkDivisionRule(s) == true)) {
			int foo = 0;
			int bar = 0;
			int qix = 0;

			if (Integer.parseInt(s) % x == 0) {
				foo = foo + 1;
			}
			if (Integer.parseInt(s) % y == 0) {
				bar = bar + 1;
			}
			if (Integer.parseInt(s) % z == 0) {
				qix = qix + 1;
			}

			String fo = new String(new char[foo]).replace("\0", "Foo");
			String ba = new String(new char[bar]).replace("\0", "Bar");
			String qi = new String(new char[qix]).replace("\0", "Qix");
			String str = fo + ba + qi;

			for (int i = 0; i < s.length(); i++) {

				// if ((s.charAt(i)) == ((char) x)){
				if (this.checkContainsRule(Character.toString(s.charAt(i)))
						|| this.checkContainsZero(Character.toString(s.charAt(i)))) {
					if (Character.toString(s.charAt(i)).equals(String.valueOf(x))) {
						str = str + "Foo";
					} else if (Character.toString(s.charAt(i)).equals(String.valueOf(y))) {
						str = str + "Bar";
					} else if (Character.toString(s.charAt(i)).equals(String.valueOf(z))) {
						str = str + "Qix";
					} else if (Character.toString(s.charAt(i)).equals(String.valueOf(zero))) {
						str = str + "*";
					}
				}

			}
			return str;
		}
		return s;
	}

	@Override
	public boolean checkContainsRule(String s) {
		// TODO Auto-generated method stub
		boolean b = false;
		if (s.contains(String.valueOf(x)) || s.contains(String.valueOf(y)) || s.contains(String.valueOf(z))) {
			b = true;
		}
		return b;
	}

	@Override
	public boolean checkDivisionRule(String s) {
		// TODO Auto-generated method stub
		boolean b = false;
		if (Integer.parseInt(s) % x == 0 || Integer.parseInt(s) % y == 0 || Integer.parseInt(s) % z == 0) {
			b = true;
		}
		return b;
	}

	@Override
	public boolean checkContainsZero(String s) {
		// TODO Auto-generated method stub
		boolean b = false;
		if (s.contains(String.valueOf(zero))) {
			b = true;
		}
		return b;
	}

}
