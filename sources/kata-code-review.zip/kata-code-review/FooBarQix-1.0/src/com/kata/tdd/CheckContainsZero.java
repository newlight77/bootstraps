package com.kata.tdd;

public interface CheckContainsZero {

	boolean checkContainsZero(String s);

}
