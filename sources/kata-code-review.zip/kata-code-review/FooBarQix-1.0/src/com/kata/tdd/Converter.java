package com.kata.tdd;

public interface Converter {

	String compute (String s);
} 
