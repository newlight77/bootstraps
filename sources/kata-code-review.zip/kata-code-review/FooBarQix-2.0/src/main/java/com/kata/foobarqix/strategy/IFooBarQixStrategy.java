package com.kata.foobarqix.strategy;

public interface IFooBarQixStrategy {

  String compute(String value);

}
