package com.kata.foobarqix.strategy;

public interface IStrategyParameter {

  String getLabel();

  int getValue();
}
