package com.kata.mybankaccount.test;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.kata.mybankaccount.domain.Account;
import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.exceptions.TransactionException;
import com.kata.mybankaccount.repository.AccountRepository;
import com.kata.mybankaccount.repository.TransactionRepository;
import com.kata.mybankaccount.services.AccountService;
import com.kata.mybankaccount.services.TransactionService;
import com.kata.mybankaccount.services.impl.AccountServiceImpl;
import com.kata.mybankaccount.services.impl.TransactionServiceImpl;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AccountServiceTest {

	private AccountServiceImpl accountServiceImpl;
	@Mock
	AccountRepository accountRepo;

	@Before
	public void initialize() {
		accountServiceImpl = new AccountServiceImpl(accountRepo);
	}

	@Test
	public void should_find_account_by_id() {
		Account account = new Account();

		given(accountRepo.findAll()).willReturn(Arrays.asList(account));

		accountServiceImpl.findByAccountId(account.getAccountId());

		verify(accountRepo).findByAccountId(account.getAccountId());

	}

	@Test
	public void should_update_balance_after_deposit() {
		int expected = 100;
		int result = accountServiceImpl.deposit(0, 100);
		assertThat(expected, is(equalTo(result)));

	}

	@Test
	public void should_update_balance_after_withdraw() {
		int expected = 70;
		int result = accountServiceImpl.withdraw(100, 30);
		assertThat(expected, is(equalTo(result)));

	}

	@Test
	public void should_update_and_store_balance_after_deposit_or_widhrawal() {
		int balance = 100;
		Account account = new Account();

		given(accountRepo.findAll()).willReturn(Arrays.asList(account));

		accountServiceImpl.update(account, balance);

		verify(accountRepo).save(account);
	}

	@Test
	public void should_store_account() {
		Account account = new Account();

		given(accountRepo.findAll()).willReturn(Arrays.asList(account));

		accountServiceImpl.save(account);

		verify(accountRepo).save(account);
	}
	
	@Test
	public void should_return_all_account() {
		
		accountServiceImpl.findAll();
		
		verify(accountRepo).findAll();
	}

	@Test
	public void should_delete_account_by_id() {
		Account account = new Account();
		
		when(accountRepo.findByAccountId(account.getAccountId())).thenReturn(account);
		
		accountServiceImpl.delete(account.getAccountId());
		
		verify(accountRepo).delete(account);
	}
}
