package com.kata.mybankaccount.test;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.kata.mybankaccount.domain.Account;
import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.exceptions.TransactionException;
import com.kata.mybankaccount.repository.AccountRepository;
import com.kata.mybankaccount.repository.TransactionRepository;
import com.kata.mybankaccount.services.impl.AccountServiceImpl;
import com.kata.mybankaccount.services.impl.TransactionFactory;
import com.kata.mybankaccount.services.impl.TransactionServiceImpl;

import static org.mockito.Mockito.verify;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.BDDMockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceTest {

	private TransactionServiceImpl transactionServiceImpl;
	private TransactionFactory transactionFactory;
	@Mock
	AccountRepository accountRepo;
	@Mock
	TransactionRepository transactionRepo;
	@Mock
	AccountServiceImpl accountServiceImpl;

	@Before
	public void initialize() {
		transactionServiceImpl = new TransactionServiceImpl(transactionRepo);
		transactionFactory = new TransactionFactory();
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	@Test
	public void should_store_deposit_transaction() {

		Transaction transaction = new Transaction();

		given(transactionRepo.findAll()).willReturn(Arrays.asList(transaction));

		transactionServiceImpl.addDepositTransaction(transaction);

		verify(transactionRepo).save(transaction);
	}

	@Test
	public void should_store_withdrawal_transaction() throws TransactionException {
		Transaction transaction = new Transaction();

		given(transactionRepo.findAll()).willReturn(Arrays.asList(transaction));

		transactionServiceImpl.addWithdrawalTransaction(transaction);

		verify(transactionRepo).save(transaction);
	}

	@Test
	public void should_find_transactions_by_accoundId() {
		Account account = new Account();
		given(accountRepo.findAll()).willReturn(Arrays.asList(account));

		transactionServiceImpl.findByAccountId(account.getAccountId());

		verify(transactionRepo).findByAccountId(account.getAccountId());

	}

	@Test
	public void should_throw_exception_when_insufficient_funds() throws TransactionException {
		thrown.expect(TransactionException.class);
		thrown.expectMessage("Solde insuffisant!");
		transactionServiceImpl.compare(10, 20);
	}

	@Test
	public void should_return_true_when_sufficient_funds() throws TransactionException {
		boolean expected = true;
		boolean result = transactionServiceImpl.compare(20, 10);
		assertThat(result, is(equalTo(expected)));
	}
	
	@Test
	public void should_return_transaction_list_to_print() {
		Account account = new Account();

		given(accountRepo.findAll()).willReturn(Arrays.asList(account));

		transactionServiceImpl.printStatement(account.getAccountId());

		verify(transactionRepo).findByAccountId(account.getAccountId());
	}

}
