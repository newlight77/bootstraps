package com.kata.mybankaccount.services;

import java.util.List;

import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.exceptions.TransactionException;

public interface TransactionService {

	public Transaction addDepositTransaction(Transaction transaction);

	
	public Transaction addWithdrawalTransaction(Transaction transaction) throws TransactionException;

	
	public List<Transaction> findByAccountId(long accountId);

	public void printStatement(long accountId);

	
	public boolean compare(int balance, int amount) throws TransactionException;	
	
	public int getBalanceOfLastTransaction();
	


}
