package com.kata.mybankaccount.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.kata.mybankaccount.domain.Transaction;

@Repository
	public interface TransactionRepository extends JpaRepository<Transaction, Long>{

	//public Transaction save(Transaction transaction);
	
	@Query(value ="SELECT * FROM Transaction WHERE accountId = ?0")
	public List<Transaction> findByAccountId(long accountId);
	
	@Query(value = "SELECT * FROM Transaction WHERE transactionId = ?0")
	public Transaction findByTransactionId(long transactionId);
	
	@Query(value ="SELECT * FROM Transaction")
	public List<Transaction> getAll();
}
