package com.kata.mybankaccount.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.kata.mybankaccount.domain.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long>{

	@Query(value ="SELECT * FROM Account")
	public List<Account> getAll();

	@Query(value = "SELECT * FROM Account WHERE accountId = ?0")
	public Account findByAccountId(long accountId);
	
	public Account save(Account account);
	
	@Query(value = "SELECT balance FROM Account WHERE accountId = ?0")
	public int getBalance (long accountId);

}
