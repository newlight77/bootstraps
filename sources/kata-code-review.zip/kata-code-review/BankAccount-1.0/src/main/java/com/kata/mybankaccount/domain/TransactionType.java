package com.kata.mybankaccount.domain;

public enum TransactionType {
DEPOSIT, WITHDRAWAL
}
