package com.kata.mybankaccount.domain;

import java.util.Date;

import javax.persistence.Entity;



@Entity
public class Transaction implements Comparable<Transaction>{

	private long transactionId;
	private long accountId;
	private Date date;
	private int amount;
	private int balance;
	private TransactionType type;
	
	public Transaction() {
	}
	
	public Transaction(long accountId, int amount) {
		super();
		this.accountId = accountId;
		this.amount = amount;
	}
	
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public TransactionType getType() {
		return type;
	}
	public void setType(TransactionType type) {
		this.type = type;
	}

	public int compareTo(Transaction o) {
	    return getDate().compareTo(o.getDate());
	}

//	@Override
//	public String toString() {
//		return "Transaction [transactionId=" + transactionId + ", accountId=" + accountId + ", date=" + date
//				+ ", amount=" + amount + ", balance=" + balance + ", type=" + type + "]";
//	}

//	@Override
//	public String toString() {
//		return "Transaction [date=" + date + ", " + "||" +", amount=" + amount + ", " + "||" +", balance=" + balance + "]";
//	}

	
	
	
}
