package com.kata.mybankaccount.services.impl;

import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.exceptions.TransactionException;
import com.kata.mybankaccount.repository.AccountRepository;
import com.kata.mybankaccount.repository.TransactionRepository;
import com.kata.mybankaccount.services.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {

	private static final Logger LOGGER = Logger.getLogger(AccountServiceImpl.class.getName());

	private TransactionRepository transactionRepo;

	public TransactionServiceImpl(TransactionRepository transactionRepo) {
		this.transactionRepo = transactionRepo;
	}

	public Transaction addDepositTransaction(Transaction transaction) {
		return transaction = transactionRepo.save(transaction);
	}

	public Transaction addWithdrawalTransaction(Transaction transaction) throws TransactionException {
		return transaction = transactionRepo.save(transaction);
	}

	public List<Transaction> findByAccountId(long accountId) {
		return transactionRepo.findByAccountId(accountId);
	}

	public boolean compare(int balance, int amount) throws TransactionException {
		if (balance >= amount) {
			return true;
		} else
			throw new TransactionException("Solde insuffisant!");
	}

	public int getBalanceOfLastTransaction() {
		int amount = 0;
		List<Transaction> transactions = transactionRepo.getAll();
		if (!transactions.isEmpty()) {
			Collections.sort(transactions, Collections.reverseOrder());
			amount = transactions.get(transactions.size()).getBalance();
		}
		return amount;
	}
	
	public void printStatement(long accountId) {
		List<Transaction> transactions = transactionRepo.findByAccountId(accountId);
		Collections.sort(transactions, Collections.reverseOrder());

		transactions.forEach(t -> LOGGER.info(t.toString()));
	}

}
