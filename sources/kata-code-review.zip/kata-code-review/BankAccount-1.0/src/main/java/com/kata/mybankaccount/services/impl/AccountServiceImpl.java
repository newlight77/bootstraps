package com.kata.mybankaccount.services.impl;

import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.stereotype.Service;

import com.kata.mybankaccount.domain.Account;
import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.repository.AccountRepository;
import com.kata.mybankaccount.repository.TransactionRepository;
import com.kata.mybankaccount.services.AccountService;
import com.kata.mybankaccount.services.TransactionService;

@Service
public class AccountServiceImpl implements AccountService {


	private AccountRepository accountRepo;

	public AccountServiceImpl(AccountRepository accountRepo) {
		this.accountRepo = accountRepo;
	}

	@Override
	public Account findByAccountId(long accountId) {
		return accountRepo.findByAccountId(accountId);
	}

	public int deposit(int initBalance, int amount) {
		int balance = initBalance + amount;
		return balance;
	}

	public int withdraw(int initBalance, int amount) {
		int balance = initBalance - amount;
		return balance;
	}

	@Override
	public Account update(Account account, int balance) {
		account.setBalance(balance);
		return accountRepo.save(account);
	}

	

	@Override
	public Account save(Account account) {
		return accountRepo.save(account);
	}

	@Override
	public List<Account> findAll() {
		return accountRepo.findAll();
	}

	@Override
	public boolean delete(long accountId) {
		boolean del = true;
		Account account = accountRepo.findByAccountId(accountId);
		accountRepo.delete(account);
		if (accountRepo.findByAccountId(accountId) !=null) {
			del = false;
		}
		return del;
	}

}
