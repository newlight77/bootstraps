package com.kata.mybankaccount.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.json.JsonReadContext;
import com.kata.mybankaccount.domain.Account;
import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.exceptions.TransactionException;
import com.kata.mybankaccount.services.AccountService;
import com.kata.mybankaccount.services.TransactionService;
import com.kata.mybankaccount.services.impl.TransactionFactory;

@RestController
public class TransactionController {

	TransactionFactory transactionFactory;
	TransactionService transactionService;
	AccountService accountService;
	
	
	@PostMapping
	public Transaction deposit(@PathVariable long accountId, @PathVariable int amount) {
		Transaction transaction = new Transaction();

		Account account = accountService.findByAccountId(accountId);
		if (account != null) {
		transaction = transactionFactory.generateDepositTransaction(accountId, amount);
		if (transaction !=null) {
			transaction =  transactionService.addDepositTransaction(transaction);
			if (transaction != null) {
				int balance = accountService.deposit(account.getBalance(), amount);
				accountService.update(account, balance);
			}
		}
		}
		return transaction;
	}

	@PostMapping
	public Transaction withdraw(@PathVariable long accountId, @PathVariable int amount) throws TransactionException {
		Transaction transaction = new Transaction();
		Account account = accountService.findByAccountId(accountId);
		if (account != null) {
			if (transactionService.compare(account.getBalance(), amount)) {
				transaction = transactionFactory.generateDepositTransaction(accountId, amount);
				if (transaction != null) {
					transaction = transactionService.addWithdrawalTransaction(transaction);
					if (transaction != null) {
						int balance = accountService.deposit(account.getBalance(), amount);
						accountService.update(account, balance);
					}
				}
			}
		}
		return transaction;
	}
	
	
	@GetMapping 
	public List<Transaction> findTransactionsByAccountId(@PathVariable long accountId){
		List<Transaction> transactions = new ArrayList<Transaction>();
		transactions = transactionService.findByAccountId(accountId);
		return transactions;
	}
	
	@GetMapping
	public void printStatement(@PathVariable long accountId){
		
		if (accountService.findByAccountId(accountId) !=null) {
			transactionService.printStatement(accountId);
		}
	}
}
