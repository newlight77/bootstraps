package com.kata.mybankaccount.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.kata.mybankaccount.domain.Account;

@Service
public interface AccountService {
	
	public Account update(Account account, int balance);
	
	public Account save(Account account);

	public int deposit(int initBalance, int amount);

	public int withdraw(int initBalance, int amount);
		
	public Account findByAccountId(long accountId);
	
	public List<Account> findAll();
	
	public boolean delete(long accountId);

}
