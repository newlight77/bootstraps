package com.kata.mybankaccount.services.impl;

import java.util.Date;
import java.util.UUID;

import com.kata.mybankaccount.domain.Transaction;
import com.kata.mybankaccount.domain.TransactionType;

public class TransactionFactory{

	private TransactionServiceImpl transactionServiceImpl;
	
	public Transaction generateDepositTransaction(long accountId, int amount) {
		Transaction transaction = new Transaction();
		transaction.setAccountId(accountId);
		transaction.setAmount(amount);
		transaction.setBalance(transactionServiceImpl.getBalanceOfLastTransaction() + amount);
		transaction.setDate(new Date());
		transaction.setType(TransactionType.DEPOSIT);
		transaction.setTransactionId(Integer.parseInt(UUID.randomUUID().toString()));
		return transaction;
	}

	public Transaction generateWithdrawalTransaction(long accountId, int amount) {
		Transaction transaction = new Transaction();
		transaction.setAccountId(accountId);
		transaction.setAmount(amount);
		transaction.setBalance(transactionServiceImpl.getBalanceOfLastTransaction() - amount);
		transaction.setDate(new Date());
		transaction.setType(TransactionType.WITHDRAWAL);
		transaction.setTransactionId(Integer.parseInt(UUID.randomUUID().toString()));
		return transaction;
	}

}
