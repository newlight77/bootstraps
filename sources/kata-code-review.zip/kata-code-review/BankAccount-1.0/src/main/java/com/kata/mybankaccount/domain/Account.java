package com.kata.mybankaccount.domain;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Builder;
import lombok.Data;

@Entity
public class Account {
	
	@Id
	private long accountId;
	private int balance;
	public long getAccountId() {
		return accountId;
	}
	
	public Account() {
		
	}
	public Account(int accountId, int balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	

}
