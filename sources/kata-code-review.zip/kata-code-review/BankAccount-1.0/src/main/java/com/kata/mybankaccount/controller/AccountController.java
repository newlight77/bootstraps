package com.kata.mybankaccount.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kata.mybankaccount.domain.Account;
import com.kata.mybankaccount.services.AccountService;

@RestController
public class AccountController {
	
	private AccountService accountService;
	
	@GetMapping
	public Account saveAccount(@RequestBody Account account){
		return accountService.save(account);
	}
	
	@GetMapping
	public List<Account> findAllAccounts(){
		List<Account> accounts = new ArrayList<Account>();
		accounts = accountService.findAll();
		return accounts;
	}

	
	@GetMapping
	public Account findAccountByAccountId(@PathVariable long accountId) {
		Account account = new Account();
		account  = accountService.findByAccountId(accountId);
		return account;		
	}
	
	@DeleteMapping
	public boolean deleteAccount (@PathVariable long accountId) {
		return accountService.delete(accountId);
	}

}
